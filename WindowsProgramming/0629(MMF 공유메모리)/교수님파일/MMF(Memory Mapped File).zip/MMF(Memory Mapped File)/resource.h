//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// MMF(Memory Mapped File).rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_DIALOG_MMF_FIRST            101
#define IDC_BUTTON_OPEN                 1002
#define IDC_BUTTON2                     1003
#define IDC_BUTTON_SAVE                 1003
#define IDC_EDIT                        1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
