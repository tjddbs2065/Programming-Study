#include "MySystemError.h"
int _tmain(void)
{
	_tsetlocale(LC_ALL, _T("korean"));
	
	return 0;
}
